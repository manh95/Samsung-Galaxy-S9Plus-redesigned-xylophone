# :feature:search module
## Dependency graph
![Dependency graph](../../docs/images/graphs/dep_graph_feature_search.svg)
