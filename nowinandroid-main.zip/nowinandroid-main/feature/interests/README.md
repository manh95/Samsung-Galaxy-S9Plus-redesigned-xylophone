# :feature:interests module
## Dependency graph
![Dependency graph](../../docs/images/graphs/dep_graph_feature_interests.svg)
